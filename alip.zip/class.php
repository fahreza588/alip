<?php
/*
	 Author : @yarzcode X alip
	 Web    : yarzc0de.co.id
	 FB     : fb.com/yarzc0de
*/

class Bli {
		public function isi($login,$la,$email){
		$headers = array();
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36';
		$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
		$headers[] = 'Accept-Language: en-US,en;q=0.5';
		$headers[] = 'Accept-Encoding: gzip, deflate';
		$headers[] = 'DNT: 1';
		$headers[] = 'connection: close';
		$headers[] = 'Referer: https://www.blibli.com/register?redirect=^%^2F';
		$headers[] = 'Accept-Language: en-US,en;q=0.9';
		$headers[] = 'Cookie: '.$login;
		$a = curl($email,"https://www.blibli.com/backend/member-voucher/referral/child/$la", null, $headers);
		return $a;
	}
	public function join($login,$email){
		$headers = array();
		$headers[] = 'Accept: application/json, text/plain, */*';
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36';
		$headers[] = 'Content-Type: application/json;charset=UTF-8';
		$headers[] = 'Origin: https://www.blibli.com';
		$headers[] = 'Referer: https://www.blibli.com/register?redirect=^%^2F';
		$headers[] = 'Accept-Language: en-US,en;q=0.9';
		$headers[] = 'Cookie: '.str_replace("\n", "", $login).'';
		$join = curl($email,"https://www.blibli.com/backend/member-voucher/referral/parent/join", false , $headers);
		return $join[1];
	}
	public function get_Refferal($login,$email){
		$headers = array();
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36';
		$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
		$headers[] = 'Accept-Language: en-US,en;q=0.5';
		$headers[] = 'Accept-Encoding: gzip, deflate';
		$headers[] = 'DNT: 1';
		$headers[] = 'connection: close';
		$headers[] = 'Referer: https://www.blibli.com/register?redirect=^%^2F';
		$headers[] = 'Accept-Language: en-US,en;q=0.9';
		$headers[] = 'Cookie: '.str_replace("\n", "", $login).'';
		$join = curl($email,"https://www.blibli.com/backend/member-voucher/referral/parent", null, $headers);
		print_r($join);
	}

	public function login($pisah,$email){
		$headers = array();
		$headers[] = 'Authority: www.blibli.com';
		$headers[] = 'Accept: application/json, text/plain, */*';
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36';
		$headers[] = 'Content-Type: application/json;charset=UTF-8';
		$headers[] = 'Origin: https://www.blibli.com';
		$headers[] = 'Sec-Fetch-Site: same-origin';
		$headers[] = 'Sec-Fetch-Mode: cors';
		$headers[] = 'Sec-Fetch-Dest: empty';
		$headers[] = 'Referer: https://www.blibli.com/register?redirect=^%^2F';
		$headers[] = 'Accept-Language: en-US,en;q=0.9';
		$headers[] = 'Cookie: '.$this->cookie();
		$login = curl($email,"https://www.blibli.com/backend/common/users/_login", '{"username":"'.$pisah[0].'","password":"'.$pisah[1].'"}', $headers);
		if(json_decode($login[1], true) ['status'] == "OK"){
		preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $login[0], $cookies);
		$ret = '';
		foreach($cookies[1] as $cm){
				$ret.= $cm."; ";
			}
			return $ret;
		} else
		{
			return "ggl";
		}

}
	public function verify($url) {
		$headers = array();
		$headers[] = 'Authority: www.blibli.com';
		$headers[] = 'Upgrade-Insecure-Requests: 1';
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36';
		$headers[] = 'Accept: application/json, text/plain, */*';
		$headers[] = 'Content-Type: application/json;charset=UTF-8';
		$headers[] = 'Sec-Fetch-Site: none';
		$headers[] = 'Sec-Fetch-Mode: navigate';
		$headers[] = 'Sec-Fetch-Dest: document';
		$headers[] = 'Accept-Language: en-US,en;q=0.9';
		$req = $this->request(trim($url), "GET", false, $headers);
		if(strpos($req[0], 'Loc')) {
			preg_match("/Location: (.*)/", $req[0], $loc);
			preg_match("/code=(.*?)&/", $loc[1], $code);
			preg_match("/logonId=(.*)/", $loc[1], $logonId);
			$ch = curl_init();
			
			curl_setopt($ch, CURLOPT_URL, 'https://www.blibli.com/backend/member/email-verification/_verify');
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, '{"logonId":'.trim($logonId[1]).'","token":'.trim($code[1]).'"}');
			curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
			
			$headers = array();
			$headers[] = 'Authority: www.blibli.com';
			$headers[] = 'Accept: application/json, text/plain, */*';
			$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36';
			$headers[] = 'Content-Type: application/json;charset=UTF-8';
			$headers[] = 'Origin: https://www.blibli.com';
			$headers[] = 'Sec-Fetch-Site: same-origin';
			$headers[] = 'Sec-Fetch-Mode: cors';
			$headers[] = 'Sec-Fetch-Dest: empty';
			$headers[] = 'Referer: https://www.blibli.com/member/p/email-verification?code=NcvRffnjD3ddmJkzuGXj52AuVLenoU^&logonId=farhunnti6568^%^40sikataja.tech';
			$headers[] = 'Accept-Language: en-US,en;q=0.9';
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			
			$result = curl_exec($ch);
			if (curl_errno($ch)) {
			    echo 'Error:' . curl_error($ch);
			}
			curl_close($ch);
			if(strpos($result, '"status":"OK')) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	public function getEmail($email) {
	    list($user,$domain) = explode("@",trim($email));
        $headersVERIF = array();
        $headersVERIF[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3';
        $headersVERIF[] = 'Cookie: _ga=GA1.2.943059698.1553681103; _gid=GA1.2.1007180967.1565707699; surl='.trim($domain).'%2F'.trim($user);
        $x = $this->request("https://generator.email/inbox1/", "GET", false, $headersVERIF);
        if(preg_match('/mulai berbelanja di Blibli/',$x[1]))
        {
            preg_match_all('/<span style="font-size: 16px"><span style="font-family: Trebuchet MS,Helvetica,sans-serif"><a href="(.*?)"/', $x[1], $url);
            if(empty($url[1][2])) {
            	return false;
            } else {
            	return $url[1][2];
            }
        } else {
        	return false;
        }
	}
	public function register($email, $password='alipxcode@1') {
		$headers = array();
		$headers[] = 'Authority: www.blibli.com';
		$headers[] = 'Accept: application/json, text/plain, */*';
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36';
		$headers[] = 'Content-Type: application/json;charset=UTF-8';
		$headers[] = 'Origin: https://www.blibli.com';
		$headers[] = 'Sec-Fetch-Site: same-origin';
		$headers[] = 'Sec-Fetch-Mode: cors';
		$headers[] = 'Sec-Fetch-Dest: empty';
		$headers[] = 'Referer: https://www.blibli.com/register?redirect=^%^2F';
		$headers[] = 'Accept-Language: en-US,en;q=0.9';
		$headers[] = 'Cookie: '.$this->cookie();
		$post = $this->request("https://www.blibli.com/backend/common/users", "POST", '{"username":'.$email.'","password":'.$password.'"}', $headers);
		if(json_decode($post[1], 1)['status'] == "OK") {
			return ['registered' => true];
		} else {
			return ['registered' => false];
		}
	}
	protected function cookie() {
        $headers = array();
        $headers[] = 'Authority: www.blibli.com';
        $headers[] = 'Upgrade-Insecure-Requests: 1';
        $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36';
        $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8';
        $headers[] = 'Accept-Language: en-US,en;q=0.9';
		$get = $this->request("https://www.blibli.com/", "GET", false, $headers);
		if(strpos($get[0], '200')) {
			$ret = '';
			preg_match_all("/Set-Cookie: (.*?);/", $get[0], $cok);
			foreach($cok[1] as $cm){
				$ret.= $cm."; ";
			}
			return $ret;
		} else {
			return false;
		}
	}
	public function data() {
		$headers = array();
		$headers[] = 'Authority: www.random-name-generator.com';
		$headers[] = 'Cache-Control: max-age=0';
		$headers[] = 'Upgrade-Insecure-Requests: 1';
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36';
		$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
		$headers[] = 'Sec-Fetch-Site: same-origin';
		$headers[] = 'Sec-Fetch-Mode: navigate';
		$headers[] = 'Sec-Fetch-User: ?1';
		$headers[] = 'Sec-Fetch-Dest: document';
		$headers[] = 'Referer: https://www.random-name-generator.com/indonesia?country=id_ID^&gender=^&n=1^&s=12011';
		$headers[] = 'Accept-Language: en-US,en;q=0.9';
		$req = $this->request("https://www.random-name-generator.com/indonesia?country=id_ID&gender=&n=1&s=".mt_rand(11111,99999)."#form", "GET", false, $headers);
		preg_match_all('/<dd class="col-sm-8">(.*?)<\/dd>/', $req[1], $aw);
		if(strpos($aw[1][1], '@')) {
			list($email, $domain) = explode("@", $aw[1][1]);
			return ['email' => $email.rand(1111,9999)."@sikataja.tech"];
		} else {
			return false;
		}
	}
	private function request($url, $method, $body=false, $headers=array()) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
		if($method == "POST") {
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
		}
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		if(count($headers) !== 0) {
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		}
		curl_setopt($ch, CURLOPT_HEADER, true);
		$exec   = curl_exec($ch);
		$header = substr($exec, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
      	$body   = substr($exec, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
        curl_close($ch);

      	return array($header,$body);
	} 
}

function curl($email,$url, $post=false, $httpheader=false,$cookie=false)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        if($cookie !== false)
        {
            curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
            curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
        }
        if($post != false)
        {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if($httpheader != false)
        {
            curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
            curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        }
        curl_setopt($ch, CURLOPT_COOKIEJAR, "cook/TRUES$email");
        curl_setopt($ch, CURLOPT_COOKIEFILE, "cook/TRUES$email");
        curl_setopt($ch, CURLOPT_COOKIE, "cook/TRUES$email");

        $response = curl_exec($ch);
        $header = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
        $body = substr($response, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
        curl_close($ch);
        return array($header, $body);
    }