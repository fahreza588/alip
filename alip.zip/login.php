<?php
require 'class.php';
$new = new Bli();
echo "List : ";
$listlist = trim(fgets(STDIN));
$list = file_get_contents($listlist);
$owh = explode("\n", $list);
$jumlah = count($owh);
for ($i=0; $i < $jumlah; $i++) { 

$pisah = explode("|", $owh[$i]);
$email = $pisah[0];
$save = "$pisah[0].txt";
$login = $new->login($pisah,$email);
if($login == "ggl") 
{
	echo "[ $i ] $pisah[0] => Fail Login \n";
} else 
{
	echo "[ $i ] $pisah[0] => Success Login => $save\n";
	$fopen = fopen("cook/$pisah[0]","a+");$fwrite = fwrite($fopen, "$login\n");fclose($fopen);
}
}