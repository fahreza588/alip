<?php
/*
Author Xalipcode
Made with heart by Xalipcode
*/
date_default_timezone_set("Asia/Jakarta");
require 'class.php';
error_reporting(0);
$a = new Bli();
$jam = file_get_contents("jam");
echo "Start jam $jam \n\n";
while(true)
{
if ($jam)
{
	$jamskrg = date('H:i:s');
	if ($jamskrg >= $jam)
	{
		echo "Starting.. \n";
		goto op;
	}
}
}
op:
while(true)
{
$listlist = "1";
$list = file_get_contents($listlist);
$owh = explode("\n", $list);
$jumlah = count($owh);
for ($i=0; $i < $jumlah; $i++) 
{ 
$pisah = explode("|", $owh[$i]);
$email = $pisah[0];
if($email == null){
} else
{
$menit = date("i");
$login = file_get_contents("cook/$pisah[0]");
$join = $a->join($login,$email);
$js = json_decode($join, true);
if($menit == 30)
{
	die("\n[".date('H:i:s')."] Bot Stopped \n");
} else
{
if($js['code'] == 200) 
{
	echo "[".date('H:i:s')."] $pisah[0] => 200 OK Success \n";
	$fopen = fopen("../result/code-success","a+");$fwrite = fwrite($fopen, "[".date('H:i:s')."] $pisah[0]|$pisah[1]|Success\n");fclose($fopen);

}else if($js['code'] == 418)
{
	
	echo "[".date('H:i:s')."] $pisah[0] => 418 PARENT_INELIGIBLE \n";
		$fopen = fopen("../result/code-fail","a+");$fwrite = fwrite($fopen, "$pisah[0] | $pisah[1] | 418 \n");fclose($fopen);

}	else if($js['code'] == 401)
{
	echo "[".date('H:i:s')."] $email => UNAUTHORIZED \n";
} else if(preg_match('/<title>Access Denied<\/title>/', $join))
{
	echo "[".date('H:i:s')."] $pisah[0] => Access Denied \n";
}
else
{
	$i--;
	echo "[".date('H:i:s')."] $pisah[0] => BAD_REQUEST \n";
}
}
}
}
}